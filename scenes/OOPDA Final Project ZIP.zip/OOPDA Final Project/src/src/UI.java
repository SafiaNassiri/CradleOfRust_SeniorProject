package src;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

public class UI 
{
    CanvasPanel cp;
    Font arial_40, arial_80B; // fonts
    BufferedImage keyImage;
    public boolean Finished = false;

    public UI(CanvasPanel cp)
    {
        this.cp = cp;

        arial_40 = new Font("Arial", Font.PLAIN, 40); // key font
        arial_80B = new Font("Arial", Font.BOLD, 80); // ending font
        Obj_Key key = new Obj_Key();
        keyImage = key.image;
    }

    public void draw(Graphics2D g2)
    {
        if(Finished == true) // if the game ends, display text
        {
            g2.setFont(arial_40);
            g2.setColor(Color.white);

            String text;
            int textLength;
            int x; // x of text
            int y; // y of text

            text = "You escaped the cave!"; // ending text
            textLength = (int)g2.getFontMetrics().getStringBounds(text, g2).getWidth(); // size of text

            x = cp.screenWidth/2 - textLength/2; // size of text
            y = cp.screenWidth/2 - (cp.TS*3); // size of text
            g2.drawString(text, x, y); // text

        }  
        else
        {
            g2.setFont(arial_40); // key font
            g2.setColor(Color.white); // key font color
            g2.drawImage(keyImage, cp.TS/2, cp.TS/2, cp.TS, cp.TS, null); // key
            g2.drawString("x " + cp.sprite.hasKey, 65, 60); // number of keys
        }
    }
}
