package src;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.Shape;

public class Light
{
    CanvasPanel cp;
    BufferedImage dark;

    public Light(CanvasPanel cp, int circle)
    {
        dark = new BufferedImage(cp.screenWidth, cp.screenHeight, BufferedImage.TYPE_INT_ARGB); // Creates image
        Graphics2D g2 = (Graphics2D)dark.getGraphics();

        Area screenArea = new Area(new Rectangle2D.Double(0, 0, cp.screenWidth, cp.screenHeight));

        int cX = cp.sprite.sx + (cp.TS)/2;
        int cY = cp.sprite.sy + (cp.TS)/2;

        double x = cX - (circle/2);
        double y = cY - (circle/2);

        Shape circleShape = new Ellipse2D.Double(x, y, circle, circle);

        Area light = new Area(circleShape);

        screenArea.subtract(light);

        g2.setColor(new Color(0, 0, 0, 0.95f));

        g2.fill(screenArea);

        g2.dispose();
    }

    public void draw(Graphics2D g2)
    {
        g2.drawImage(dark, 0, 0, null);
    }

    public void draw(Graphics g2) 
    {
        g2.drawImage(dark, 0, 0, null);
    }
}