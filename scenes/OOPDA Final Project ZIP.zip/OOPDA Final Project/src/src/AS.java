package src;

public class AS 
{
    CanvasPanel cp;

    public AS(CanvasPanel cp)
    {
        this.cp = cp;
    }

    public void SO()
    {
        cp.ob[0] = new Obj_Key(); // Creates key image
        cp.ob[0].wx = 41 * cp.TS; // Position of key
        cp.ob[0].wy = 9 * cp.TS; // Position of key

        cp.ob[1] = new Obj_Door(); // Creates door image
        cp.ob[1].wx = 48 * cp.TS; // Postion of Door
        cp.ob[1].wy = 49 * cp.TS; // Position of DOor
    }
}
