package src;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;
public class CanvasPanel extends JPanel implements Runnable
{

	// Screen
	final int OTS = 16; // original tile size
	final int scale = 3; // size of window
	
	public final int TS = OTS * scale; // tile size
	public final int MSC = 16; // screen columns
	public final int MSR = 12; // screen rows
	public final int screenWidth = TS * MSC; // width of screen
	public final int screenHeight = TS * MSR; // height of screen

	// World
	public final int MWC = 50; // world columns
	public final int MWR = 51; // world rows
	
	//FPS
	int FPS = 60;
	
	//System
	TM tileM = new TM(this);
	Thread gT;	
	Keys key = new Keys();
	makeSound sound = new makeSound();
	public Sprite sprite = new Sprite(this,key);
	public Object ob[] = new Object[10];
	public CollisionDetector cd = new CollisionDetector(this);
	public AS as = new AS(this);
	Darkness dark = new Darkness(this);
	public UI ui = new UI(this);
	
	
	public CanvasPanel() // dimensions and such for window
	{
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setBackground(Color.BLACK);
		this.setDoubleBuffered(true);
		this.addKeyListener(key);
		this.setFocusable(true);	
	}

	public void setup() // setup for objects to be picked up and lowering render distance
	{
		as.SO();
		dark.setup();
	}
	
	public void SGT()
	{
		gT = new Thread(this);
		gT.start();
	}
	
	public void run()
	{
		double drawInterval = 1000000000/FPS;
		double lastTime = System.nanoTime() + drawInterval;
		
		while(gT != null)
		{
			//update information such as character positions
			Update();
			//draw the screen w updated info
			repaint();
				
			try 
			{
				double remainingTime = lastTime - System.nanoTime();
				remainingTime = remainingTime / 1000000;
				
				if(remainingTime < 0)
				{
					remainingTime = 0;
				}
				Thread.sleep((long) remainingTime);
				
				lastTime += drawInterval;
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}

	public void Update()
	{
		sprite.Update(); // updates drawing of sprite
	}
	
	public void paintComponent(Graphics g)
	{ 
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
	
		//Tile
		tileM.draw(g2); // draws tiles based off of world.text

		//Object
		for(int i = 0; i < ob.length; i++)
		{
			if(ob[i] != null)
			{
				ob[i].draw(g2, this);
			}
		}

		//Sprite
		//Draw = Simulate
		sprite.Draw(g2);

		if(sprite.displayDoor != true) // if the game is finished, get rid of dark background
		{
			dark.draw(g2);
		}
		
		ui.draw(g2); // draws the keys in top left
		
		g2.dispose();
	}	

	public void se(int i) // plays sounds of key and door
	{
		sound.setFile(i);
		sound.play();
    }
}	
