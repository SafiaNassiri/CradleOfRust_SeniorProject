package src;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Obj_Door extends Object
{
    public Obj_Door()
    {
        name = "Door";
        try
        {
            image = ImageIO.read(new File("objects/Door.png"));
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        collision = true;
    }
}
