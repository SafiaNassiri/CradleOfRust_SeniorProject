package src;

public class CollisionDetector
{

    CanvasPanel gp;

    public CollisionDetector(CanvasPanel gp)
    {
       this.gp = gp;
    }

    public void checkTile(Ent entity) 
    {
        int entityLeftWorldX = entity.wx + entity.solidArea.x;  // collision detection
        int entityRightWorldX = entity.wx + entity.solidArea.x + entity.solidArea.width; // collision detection
        int entityTopWorldY = entity.wy + entity.solidArea.y;  // collision detection
        int entityBottomWorldY = entity.wy + entity.solidArea.y + entity.solidArea.height; // collision detection

        int entityLeftCol = entityLeftWorldX/gp.TS; // collision detection of left column
        int entityRightCol = entityRightWorldX/gp.TS; // collision detection of right column
        int entityTopRow = entityTopWorldY/gp.TS; // collision detection of top row
        int entityBottomRow = entityBottomWorldY/gp.TS; // oollsiion decetion of bottom row

        int tileNum1, tileNum2;

        switch(entity.direction)
        {
        case "up": // if facing up, collision detection for going up
            entityTopRow = (entityTopWorldY - entity.speed)/gp.TS;
            tileNum1 = gp.tileM.mapTileNumber[entityLeftCol][entityTopRow];
            tileNum2 = gp.tileM.mapTileNumber[entityRightCol][entityTopRow];
            if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true)
            {
                entity.collisionOn = true;
                System.out.println("Collided up");
            }
            break;
        case "down": // if facing down, collision detection for going down
             entityBottomRow = (entityBottomWorldY + entity.speed)/gp.TS;
            tileNum1 = gp.tileM.mapTileNumber[entityLeftCol][entityBottomRow];
            tileNum2 = gp.tileM.mapTileNumber[entityRightCol][entityBottomRow];
            if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true)
            {
                entity.collisionOn = true;
                System.out.println("Collided Down");
            }
            break;
        case "left": // if facing left, collision detectino for going left
             entityLeftCol = (entityLeftWorldX - entity.speed)/gp.TS;
            tileNum1 = gp.tileM.mapTileNumber[entityLeftCol][entityTopRow];
            tileNum2 = gp.tileM.mapTileNumber[entityLeftCol][entityBottomRow];
            if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true)
            {
                entity.collisionOn = true;
                System.out.println("Collided Left");
            }
            break;
        case "right": // if facing right, collision detection for going right
             entityRightCol = (entityRightWorldX + entity.speed)/gp.TS;
            tileNum1 = gp.tileM.mapTileNumber[entityRightCol][entityTopRow];
            tileNum2 = gp.tileM.mapTileNumber[entityRightCol][entityBottomRow];
            if(gp.tileM.tile[tileNum1].collision == true || gp.tileM.tile[tileNum2].collision == true)
            {
                entity.collisionOn = true;
                System.out.println("Collided right");
            }
            break;
        }

    }

    
    public int checkObject(Ent entity, boolean sprite)
    {
        int index = 999;

        for(int i = 0; i < gp.ob.length; i++)
        {
            if(gp.ob[i] != null)
            {
                entity.solidArea.x = entity.wx + entity.solidArea.x;
                entity.solidArea.y = entity.wy + entity.solidArea.y;

                gp.ob[i].solidArea.x = gp.ob[i].wx + gp.ob[i].solidArea.x;
                gp.ob[i].solidArea.y = gp.ob[i].wy + gp.ob[i].solidArea.y;

                switch(entity.direction)
                {
                    case "up":
                        entity.solidArea.y -= entity.speed;
                        if(entity.solidArea.intersects(gp.ob[i].solidArea))
                        {
                            if(gp.ob[i].collision == true)
                            {
                                entity.collisionOn = true; // add collision for up
                            }
                            if(sprite == true)
                            {
                                index = i;
                            }
                        }
                        break;
                    case "down":
                        entity.solidArea.y += entity.speed;
                        if(entity.solidArea.intersects(gp.ob[i].solidArea))
                        {
                            if(gp.ob[i].collision == true)
                            {
                                entity.collisionOn = true; // add collision for down
                            }
                            if(sprite == true)
                            {
                                index = i;
                            }
                        }
                        break;
                    case "left":
                        entity.solidArea.x -= entity.speed;
                        if(entity.solidArea.intersects(gp.ob[i].solidArea))
                        {
                            if(gp.ob[i].collision == true)
                            {
                                entity.collisionOn = true; // add collision for left
                            }
                            if(sprite == true)
                            {
                                index = i;
                            }
                        }
                        break;
                    case "right":
                        entity.solidArea.x += entity.speed;
                        if(entity.solidArea.intersects(gp.ob[i].solidArea))
                        {
                            if(gp.ob[i].collision == true)
                            {
                                entity.collisionOn = true; // add collision for right
                            }
                            if(sprite == true)
                            {
                                index = i;
                            }
                        }
                        break;
                }
            entity.solidArea.x = entity.solidAreaDefaultX;
            entity.solidArea.y = entity.solidAreaDefaultY;
            gp.ob[i].solidArea.x = gp.ob[i].solidAreaDefaultX;
            gp.ob[i].solidArea.y = gp.ob[i].solidAreaDefaultY;
            }
            
        }

        return index;
    }
}