package src;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Sprite extends Ent
{
	CanvasPanel gp;
	Keys key;

	public final int sx;
	public final int sy;
	public boolean displayDoor = false;

	int hasKey = 0;

	public Sprite(CanvasPanel gp, Keys key)
	{
		this.gp = gp;
		this.key = key;

		sx = gp.screenWidth/2 - (gp.TS/2); // middle of screen
		sy = gp.screenHeight/2 - (gp.TS/2); // middle of screen

		solidArea = new Rectangle();
		solidArea.x = 10;
		solidArea.y = 20;
		solidAreaDefaultX = solidArea.x;
		solidAreaDefaultY = solidArea.x;
		solidArea.width = 22;
		solidArea.height = 25;
		
		
		setDefault();
		getSpriteImage();
	}
	
	public void setDefault()
	{
		wx = gp.TS * 24; // position on map
		wy = gp.TS * 26; // position on map
		speed = 2;
		direction = "down";
	}
	
	public void getSpriteImage()
	{
		try 
		{
			runR1 = ImageIO.read(new File("PC/PC2.png.png"));
			runR2 = ImageIO.read(new File("PC/PC3.png.png"));
			runB1 = ImageIO.read(new File("PC/PC5.png.png"));
			runB2 = ImageIO.read(new File("PC/PC6.png.png"));
			runL1 = ImageIO.read(new File("PC/PC7.png.png"));
			runL2 = ImageIO.read(new File("PC/PC8.png.png"));
			runF1 = ImageIO.read(new File("PC/PC9.png.png"));
			runF2 = ImageIO.read(new File("PC/PC10.png.png"));
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void Update()
	{
		if(key.up == true || key.down == true || key.left == true || key.right == true)
		{
			if(key.up == true)
			{
				direction = "up";
			}
			else if(key.down == true)
			{
				direction = "down";
			}
			else if(key.left == true)
			{
				direction = "left";
			}
			else if(key.right == true)
			{
				direction = "right";
			}

			//Check tile Collision
			collisionOn = false;
			gp.cd.checkTile(this);

			// collision is false, player can move
			if(collisionOn == false)
			{
				switch(direction)
				{
					case "up":
						wy -= speed;
						break;
					case "down":
						wy += speed;
						break;
					case "left":
						wx -= speed;
						break;
					case "right":
						wx += speed;
						break;
				}
			}

			//Check Object Collision
			int obIndex = gp.cd.checkObject(this, true);
			pickUpObject(obIndex);

			//If Collision is false, Sprite can move
			if(collisionOn == false)
			{
				switch(direction)
				{
					case "up": wy -= speed; break;
					case "down": wy += speed; break;
					case "left": wx -= speed; break;
					case "right": wx += speed; break;
				}
			}
		
			spriteCounter++;
			if(spriteCounter > 10)
			{
				if(spriteNum == 1)
				{
					spriteNum = 2;
				}
				else if(spriteNum == 2)
				{
					spriteNum = 1;
				}
				spriteCounter = 0;
			}
		}
	}
	BufferedImage doorImage = null;

	public void pickUpObject(int i)
	{
		if(i != 999)
		{
			String objectName = gp.ob[i].name;

			switch(objectName)
			{
				case "Key":
					gp.se(1);
					hasKey++;
					gp.ob[i] = null;
					System.out.println("Key:" + hasKey);
					break;
				case "Door":
					if(hasKey > 0)
					{
						gp.se(2);
						gp.ob[i] = null;
						hasKey--;
						gp.ui.Finished = true;
						gp.se(3);
						displayDoor = true;
						// Load the image you want to display
						try 
						{
							doorImage = ImageIO.read(new File("tile/ending.png"));
						} 
						catch (IOException e) 
						{
							e.printStackTrace();
						}
	
						// Draw the image on the screen
						Graphics2D g2d = (Graphics2D) gp.getGraphics();
						int imageX = 100;// calculate the x-coordinate where you want to draw the image
						int imageY = 100;// calculate the y-coordinate where you want to draw the image
						g2d.drawImage(doorImage, imageX, imageY, null);
					}
					System.out.println("Key:" + hasKey);
					break;
			}
		}
	}

	public void Draw(Graphics2D g2)
	{		
		BufferedImage image = null;
		
		switch(direction)
		{
		case "up":
			if(spriteNum == 1)
			{
				image = runB1;
			}
			if(spriteNum == 2)
			{
				image = runB2;
			}
			break;
		case "down":
			if(spriteNum == 1)
			{
				image = runF1;
			}
			if(spriteNum == 2)
			{
				image = runF2;
			}
			break;
		case "right":
			if(spriteNum == 1)
			{
				image = runR1;
			}
			if(spriteNum == 2)
			{
				image = runR2;
			}
			break;
		case "left":
			if(spriteNum == 1)
			{
				image = runL1;
			}
			if(spriteNum == 2)
			{
				image = runL2;
			}
			break;
		}
		g2.drawImage(image, sx, sy, gp.TS, gp.TS, null);
		if (displayDoor) 
		{
			g2.drawImage(doorImage, 0, 0, gp.screenWidth, gp.screenHeight, null);
		}
	}
	
}
