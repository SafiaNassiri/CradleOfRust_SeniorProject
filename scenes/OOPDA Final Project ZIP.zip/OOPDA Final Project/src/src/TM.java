package src;

import java.awt.Graphics2D;
import java.io.IOException;
import java.util.Scanner;
import java.io.File;

import javax.imageio.ImageIO;

public class TM 
{
    CanvasPanel gp;
    public Tile[] tile;
    public int mapTileNumber[][];

    public TM(CanvasPanel gp)
    {
        this.gp = gp;

        tile = new Tile[10]; // tile
        mapTileNumber = new int[gp.MWC][gp.MWR]; // generated world map

        getImage();
        loadMap("maps/world1.txt"); // reference map for where things are
    }

    public void getImage()
    {
        try
        {
            tile[0] = new Tile(); // adds new tile to set
            tile[0].image = ImageIO.read(new File("tile/black.png")); // black cave image
            tile[0].collision = true;

            tile[5] = new Tile();
            tile[5].image = ImageIO.read(new File("tile/grey wall.png")); // grey wall
            tile[5].collision = true;

            tile[6] = new Tile();
            tile[6].image = ImageIO.read(new File("tile/Stone.png")); // Stone 
            tile[6].collision = false;
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void loadMap(String filePath) // This is used to move the "camera" and load the world map while the sprite stays in one place
    {
        try
        {
            Scanner br = new Scanner(new File(filePath));

            int col = 0; // Column on map
            int row = 0; // Rows on map

            while(col < gp.MWC && row < gp.MWR)
            {
                String line = br.nextLine();

                while (col < gp.MWC) // While colums are less than the Map World Columns
                {
                    String numbers[] = line.split(" ");
                    
                    int num = Integer.parseInt(numbers[col]); // parse through colums on screen

                    mapTileNumber[col][row] = num;
                    col++; // add a column
                }
                if(col == gp.MWC)
                {
                    col = 0;
                    row++; // If the colums are okay (moving up and down so columns don't change) then add a row
                }
            }
            
            br.close();
            
        } 
        catch(Exception e)
        {

        }
    }

    public void draw(Graphics2D g2)
    {
        int wc = 0; // World Columns
        int wr = 0; // World Rows
        
        while(wc < gp.MWC && wr < gp.MWR) // While the columns and rows on the screen are less than what they are supposed to be 
                                            // (player is moving), draw new columns
        {
            int tileNumber = mapTileNumber[wc][wr];

            int wx = wc * gp.TS; // World X
            int wy = wr * gp.TS; // World Y
            int sx = wx - gp.sprite.wx + gp.sprite.sx; // Screen X (returns the tile screen position)
            int sy = wy - gp.sprite.wy + gp.sprite.sy; // Screen Y (returns the tile screen position)

            if(wx + gp.TS > gp.sprite.wx - gp.sprite.sx && 
               wx - gp.TS < gp.sprite.wx + gp.sprite.sx &&      // This if statement allows only an area around the sprite to be
               wy + gp.TS > gp.sprite.wy - gp.sprite.sy &&      // drawn, rather than the entire map being drawn.
               wy - gp.TS < gp.sprite.wy + gp.sprite.sy)        
               {
                    g2.drawImage(tile[tileNumber].image, sx, sy, gp.TS, gp.TS, null); // Draws the tiles
               }
            wc++;

            if(wc == gp.MWC) // Same as loadmap essentially
            {
                wc = 0;
                wr++;
            }
        }

    }
}

