package src;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class makeSound
{
	Clip sound;
	URL soundURL[] = new URL[5];

	public makeSound()
	{
		try // file paths to all sounds
		{
			soundURL[0] = new File("Sounds/gravel.wav").toURI().toURL();
			soundURL[1] = new File("Sounds/chime_upD.wav").toURI().toURL();	
			soundURL[2] = new File("Sounds/door.wav").toURI().toURL();
			soundURL[3] = new File("Sounds/cheeringe.wav").toURI().toURL();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
	}

	public void setFile(int i)
	{
		try
		{
			AudioInputStream audio = AudioSystem.getAudioInputStream(soundURL[i]);
			sound = AudioSystem.getClip();
			sound.open(audio);
		}
		catch(Exception e)
		{

		}
	}

	public void play()
	{
		sound.start();
	}

	public void stop()
	{
		sound.stop();
	}
}
