package src;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Ent 
{
	public int wx, wy; // world x and y
	public int speed; // speed of entity

	public BufferedImage runF1, runF2, runB1, runB2, runL1, runL2, runR1, runR2; // images of running left, right, up, down
	public String direction; // direction of sprite
	
	public int spriteCounter = 0;
	public int spriteNum = 1;
	public Rectangle solidArea; // collision detection
	public boolean collisionOn = false; // doesn't collide with itself
	public int solidAreaDefaultX, solidAreaDefaultY; // collision detection
}
