package src;

import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Object
{
    public BufferedImage image;
    public String name;
    public boolean collision = false;
    public int wx, wy; // world x and y
    public Rectangle solidArea = new Rectangle(0, 0, 48, 48); // collision
    public int solidAreaDefaultX = 0; // collision
    public int solidAreaDefaultY = 0; // collision

    public void draw(Graphics2D g2, CanvasPanel cp)
    {
            int sx = wx - cp.sprite.wx + cp.sprite.sx; // Screen X (returns the tile screen position)
            int sy = wy - cp.sprite.wy + cp.sprite.sy; // Screen Y (returns the tile screen position)

            if(wx + cp.TS > cp.sprite.wx - cp.sprite.sx && 
               wx - cp.TS < cp.sprite.wx + cp.sprite.sx &&      // This if statement allows only an area around the sprite to be
               wy + cp.TS > cp.sprite.wy - cp.sprite.sy &&      // drawn, rather than the entire map being drawn.
               wy - cp.TS < cp.sprite.wy + cp.sprite.sy)    
               {
                    g2.drawImage(image, sx, sy, cp.TS, cp.TS, null); // Draws the tiles
               }
    }
}