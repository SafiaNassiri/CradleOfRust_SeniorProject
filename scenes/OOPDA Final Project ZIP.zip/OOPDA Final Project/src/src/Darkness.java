package src;

import java.awt.Graphics2D;

public class Darkness
{
    CanvasPanel cp;
    Light darkness;

    public Darkness(CanvasPanel cp)
    {
        this.cp = cp;
    }

    public void setup()
    {
        darkness = new Light(cp, 350); // lowers render distance to a circle
    }

    public void draw(Graphics2D g2)
    {
        darkness.draw(g2); // draws circles
    }
}