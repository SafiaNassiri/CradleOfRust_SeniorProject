package src;

import javax.swing.JFrame;

public class FINAL
{
	// Tyler Walters and Antonio Terilla 
	// Final Project 04/25/2024

	public static void main(String[] args) 
	{
		JFrame window = new JFrame();
		
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close button
		window.setResizable(false); // windowed
		window.setTitle("Game"); // title
		
		CanvasPanel gamePanel = new CanvasPanel();
		window.add(gamePanel);
		
		window.pack();
		
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
		gamePanel.setup(); // calls setup
		gamePanel.SGT();
	}
} // end of class
