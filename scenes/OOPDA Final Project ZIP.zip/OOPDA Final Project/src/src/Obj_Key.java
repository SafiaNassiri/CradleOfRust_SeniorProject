package src;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Obj_Key extends Object
{
    public Obj_Key()
    {
        name = "Key";
        try
        {
            image = ImageIO.read(new File("objects/Key.png"));
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }
}
